#!/usr/bin/env python3
"""Temporary field helper for 05_31 Ivolga HHM 3.1 controlled retry.

This tool is intentionally outside HHM/NLI runtime. It combines:
- historical evidence from wb-mqtt-db;
- current retained MQTT state;
- one bounded read-only wb-mqtt-serial port/Load capability probe;
- exact pre-release NLI target staging in pinned mode;
- NLI update orchestration with an explicit operator confirmation;
- passive post-install smoke/soak and journal analysis.

No firmware operations, no wb-mqtt-serial restart, no direct actuator writes.
"""
import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import statistics
import subprocess
import sys
import tempfile
import time
import urllib.request
import uuid

REPO = "psv76/Neirolinks"
PR_HEAD = "5efce9783886a991d9d1b9008860f9309b1d5559"
RUNTIME_COMMIT = "20af0c29ed37130a5d4ff051ff1fb5984a5f8193"
HEALTH_CONTRACT = "m1w2-health-v1"
NLI_VERSION = "0.1.9"
TOOL_VERSION = "2026-09-26.2"
CONFIG = Path("/mnt/data/etc/neiro/nli/config.json")
STAGE_BACKUP = Path("/mnt/data/etc/neiro/nli/config.json.pre-hhm31-retry")
RELEASE_DIR = Path("/mnt/data/etc/neiro/nli/releases")
REPORT_DIR = Path("/tmp/hhm31-field-retry")

MANIFEST = {
    "boiler": {
        "path": "NLI/releases/hhm-boiler-3.1.json",
        "sha256": "b8c45743c4d290949e42f0b459804b1e545087a788383fb0cb816edc0379d444",
    },
    "gazebo": {
        "path": "NLI/releases/hhm-gazebo-3.1.json",
        "sha256": "c3de99685ba6995ed2b51fcd74d1bc20c3c416e293691c9b42689cc857547261",
    },
}

BOILER_M1W2 = [
    ("903.09_TEMP_NONE/External Sensor 1", "903.09_TEMP_NONE/External Sensor 1 OK"),
    ("902.11_M1W2_TEMP_NONE/External Sensor 1", "902.11_M1W2_TEMP_NONE/External Sensor 1 OK"),
    ("902.09_M1W2_TEMP_NONE/External Sensor 1", "902.09_M1W2_TEMP_NONE/External Sensor 1 OK"),
    ("902.06_M1W2_TEMP_NONE/External Sensor 1", "902.06_M1W2_TEMP_NONE/External Sensor 1 OK"),
    ("902.04_M1W2_LEAK_TEMP/External Sensor 2", "902.04_M1W2_LEAK_TEMP/External Sensor 2 OK"),
    ("902.13_M1W2_LEAK_TEMP/External Sensor 2", "902.13_M1W2_LEAK_TEMP/External Sensor 2 OK"),
    ("902.02_M1W2_TEMP_NONE/External Sensor 1", "902.02_M1W2_TEMP_NONE/External Sensor 1 OK"),
    ("903.02_M1W2_LEAK_TEMP/External Sensor 2", "903.02_M1W2_LEAK_TEMP/External Sensor 2 OK"),
    ("903.06_M1W2_LEAK_TEMP/External Sensor 2", "903.06_M1W2_LEAK_TEMP/External Sensor 2 OK"),
    ("wb-m1w2_170/External Sensor 1", "wb-m1w2_170/External Sensor 1 OK"),
    ("wb-m1w2_170/External Sensor 2", "wb-m1w2_170/External Sensor 2 OK"),
    ("wb-m1w2_141/External Sensor 1", "wb-m1w2_141/External Sensor 1 OK"),
    ("wb-m1w2_141/External Sensor 2", "wb-m1w2_141/External Sensor 2 OK"),
    ("wb-m1w2_167/External Sensor 1", "wb-m1w2_167/External Sensor 1 OK"),
    ("wb-m1w2_167/External Sensor 2", "wb-m1w2_167/External Sensor 2 OK"),
    ("wb-m1w2_121/External Sensor 1", "wb-m1w2_121/External Sensor 1 OK"),
    ("wb-m1w2_173/External Sensor 1", "wb-m1w2_173/External Sensor 1 OK"),
    ("wb-m1w2_173/External Sensor 2", "wb-m1w2_173/External Sensor 2 OK"),
    ("wb-m1w2_166/External Sensor 1", "wb-m1w2_166/External Sensor 1 OK"),
]
GAZEBO_M1W2 = [("921.10_TEMP_NONE/External Sensor 1", "921.10_TEMP_NONE/External Sensor 1 OK")]
ROLE_PAIRS = {"boiler": BOILER_M1W2, "gazebo": GAZEBO_M1W2}
PROBE = {
    "gazebo": {"path": "921.10_TEMP_NONE/External Sensor 1", "input": 1, "min": -20.0, "max": 70.0},
    "boiler": {"path": "wb-m1w2_170/External Sensor 1", "input": 1, "min": -40.0, "max": 120.0},
}
GAZEBO_AIR = "921.09_MSW_TH/Temperature"
KNOWN_75_MAX_INTERVAL_S = 395  # #75 live evidence: 335, 370, 395, 355 s intervals.


def eprint(*args):
    print(*args, file=sys.stderr)


def run(cmd, timeout=60, check=False, text=True):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       timeout=timeout, text=text)
    if check and p.returncode != 0:
        raise RuntimeError("command failed (%s): %s\n%s" % (p.returncode, " ".join(cmd), p.stderr.strip()))
    return p


def have(name):
    return shutil.which(name) is not None


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def mqtt_topic(path):
    device, control = path.split("/", 1)
    return "/devices/%s/controls/%s" % (device, control)


def mqtt_multi_snapshot(paths, timeout=2):
    """Collect retained/current messages for many control paths in one subscription."""
    if not have("mosquitto_sub"):
        return {}, "mosquitto_sub missing"
    cmd = ["mosquitto_sub", "-h", "127.0.0.1", "-W", str(timeout), "-F", "%r\t%t\t%p"]
    wanted = {}
    for path in paths:
        topic = mqtt_topic(path)
        wanted[topic] = path
        cmd += ["-t", topic, "-t", topic + "/meta/error"]
    p = run(cmd, timeout=timeout + 3)
    result = {}
    for line in p.stdout.splitlines():
        parts = line.split("\t", 2)
        if len(parts) != 3:
            continue
        retain, topic, payload = parts
        error = topic.endswith("/meta/error")
        base = topic[:-11] if error else topic
        path = wanted.get(base)
        if not path:
            continue
        item = result.setdefault(path, {"value": None, "retain": None, "error": None, "error_retain": None})
        if error:
            item["error"] = payload
            item["error_retain"] = retain == "1"
        else:
            item["value"] = payload
            item["retain"] = retain == "1"
    return result, None


def rpc_call(driver, service, method, params, timeout=15):
    if not have("mosquitto_sub") or not have("mosquitto_pub"):
        raise RuntimeError("mosquitto-clients are required")
    client = "hhm31-field-%s-%s" % (os.getpid(), uuid.uuid4().hex[:8])
    req = "/rpc/v1/%s/%s/%s/%s" % (driver, service, method, client)
    reply = req + "/reply"
    request_id = int(time.time() * 1000) % 2147483647
    payload = json.dumps({"id": request_id, "params": params}, separators=(",", ":"))
    sub = subprocess.Popen(["mosquitto_sub", "-h", "127.0.0.1", "-t", reply,
                            "-C", "1", "-W", str(timeout), "-F", "%r\t%t\t%p"],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    time.sleep(0.15)
    pub = run(["mosquitto_pub", "-h", "127.0.0.1", "-t", req, "-m", payload], timeout=5)
    if pub.returncode != 0:
        sub.terminate()
        raise RuntimeError("MQTT publish failed: " + pub.stderr.strip())
    try:
        out, err = sub.communicate(timeout=timeout + 2)
    except subprocess.TimeoutExpired:
        sub.kill(); out, err = sub.communicate()
        raise RuntimeError("MQTT RPC timeout")
    if sub.returncode not in (0,):
        raise RuntimeError("MQTT RPC subscribe failed: " + err.strip())
    parts = out.strip().split("\t", 2)
    if len(parts) != 3:
        raise RuntimeError("Malformed MQTT RPC reply")
    retain, topic, body = parts
    if retain != "0" or topic != reply:
        raise RuntimeError("Unexpected retained/topic RPC reply")
    obj = json.loads(body)
    if obj.get("id") != request_id:
        raise RuntimeError("Mismatched RPC id")
    return obj


def serial_load(device_id, function, address, timeout=12):
    return rpc_call("wb-mqtt-serial", "port", "Load", {
        "device_id": device_id,
        "function": function,
        "address": address,
        "count": 1,
        "format": "HEX",
        "total_timeout": 10000,
    }, timeout=timeout)


def numeric(value):
    try:
        if isinstance(value, bool):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def probe_port_load(role):
    cfg = PROBE[role]
    path = cfg["path"]
    health = dict(ROLE_PAIRS[role])[path]
    snap, snap_err = mqtt_multi_snapshot([path, health], timeout=2)
    result = {"role": role, "path": path, "snapshot": snap, "snapshot_error": snap_err, "pass": False}
    value = numeric((snap.get(path) or {}).get("value"))
    ok_raw = str((snap.get(health) or {}).get("value", "")).lower()
    if value is None or not (cfg["min"] <= value <= cfg["max"]):
        result["error"] = "current temperature unavailable/out of range"
        return result
    if ok_raw not in ("1", "true"):
        result["error"] = "current Sensor OK is not 1"
        return result
    for p in (path, health):
        err = (snap.get(p) or {}).get("error")
        if err not in (None, ""):
            result["error"] = "active MQTT error on %s: %s" % (p, err)
            return result
    device_id = path.split("/", 1)[0]
    input_no = cfg["input"]
    try:
        t_reply = serial_load(device_id, 4, 7 + input_no - 1)
        h_reply = serial_load(device_id, 2, 16 + input_no - 1)
    except Exception as exc:
        result["error"] = "port/Load unavailable: %s" % exc
        return result
    result["temperature_reply"] = t_reply
    result["health_reply"] = h_reply
    if t_reply.get("error") is not None or h_reply.get("error") is not None:
        result["error"] = "port/Load returned RPC error"
        return result
    try:
        t_hex = t_reply["result"]["response"]
        h_hex = h_reply["result"]["response"]
    except (KeyError, TypeError):
        result["error"] = "port/Load response shape unsupported"
        return result
    if not re.fullmatch(r"[0-9a-fA-F]{4}", str(t_hex)) or not re.fullmatch(r"[0-9a-fA-F]{2}", str(h_hex)):
        result["error"] = "port/Load returned malformed HEX"
        return result
    raw = int(t_hex, 16)
    measured = (raw - 65536 if raw >= 32768 else raw) * 0.0625
    rounded_steps = math.floor(abs(measured) / 0.05 + 0.5)
    rounded = float("%.2f" % ((-1 if measured < 0 else 1) * rounded_steps * 0.05))
    result["measured_c"] = measured
    result["local_c"] = value
    result["health_hex"] = h_hex
    if raw == 32767 or not (cfg["min"] <= measured <= cfg["max"]):
        result["error"] = "hardware temperature invalid"
        return result
    if value not in (measured, rounded):
        result["error"] = "hardware/local temperature mismatch"
        return result
    if h_hex.lower() != "01":
        result["error"] = "hardware Sensor OK is not 1"
        return result
    result["pass"] = True
    return result


def history_rpc(method, params, timeout=15):
    return rpc_call("db_logger", "history", method, params, timeout=timeout)


def history_channels():
    obj = history_rpc("get_channels", {}, timeout=15)
    if obj.get("error") is not None:
        raise RuntimeError("wb-mqtt-db get_channels error: %s" % obj.get("error"))
    return (obj.get("result") or {}).get("channels") or {}


def split_channel(path):
    return path.split("/", 1)


def history_values(paths, start_ts, end_ts, limit=10000, max_records=None):
    """One bounded history query. max_records lets wb-mqtt-db aggregate while preserving min/max."""
    if not paths:
        return []
    params = {
        "ver": 0,
        "channels": [split_channel(p) for p in paths],
        "timestamp": {"gt": int(start_ts), "lt": int(end_ts)},
        "limit": limit,
        "with_milliseconds": True,
        "request_timeout": 12,
    }
    if max_records is not None:
        params["max_records"] = int(max_records)
    obj = history_rpc("get_values", params, timeout=20)
    if obj.get("error") is not None:
        raise RuntimeError("wb-mqtt-db get_values error: %s" % obj.get("error"))
    result = obj.get("result") or {}
    return result.get("values") or []


def history_values_paged(paths, start_ts, end_ts, page_limit=5000, max_pages=20):
    """Exact/raw history for narrow forensic windows, with uid pagination."""
    if not paths:
        return []
    rows = []
    uid_gt = None
    for _ in range(max_pages):
        params = {
            "ver": 0,
            "channels": [split_channel(p) for p in paths],
            "timestamp": {"gt": int(start_ts), "lt": int(end_ts)},
            "limit": page_limit,
            "with_milliseconds": True,
            "request_timeout": 12,
        }
        if uid_gt is not None:
            params["uid"] = {"gt": uid_gt}
        obj = history_rpc("get_values", params, timeout=20)
        if obj.get("error") is not None:
            raise RuntimeError("wb-mqtt-db get_values error: %s" % obj.get("error"))
        result = obj.get("result") or {}
        page = result.get("values") or []
        rows.extend(page)
        if not result.get("has_more"):
            return rows
        uids = [int(r["uid"]) for r in page if r.get("uid") is not None]
        if not uids:
            raise RuntimeError("wb-mqtt-db history pagination has_more without uid")
        next_uid = max(uids)
        if uid_gt is not None and next_uid <= uid_gt:
            raise RuntimeError("wb-mqtt-db history pagination did not advance")
        uid_gt = next_uid
    raise RuntimeError("wb-mqtt-db history pagination exceeded %d pages" % max_pages)


def by_path(values):
    out = {}
    for row in values:
        p = "%s/%s" % (row.get("device"), row.get("control"))
        out.setdefault(p, []).append(row)
    for rows in out.values():
        rows.sort(key=lambda r: float(r.get("timestamp", 0)))
    return out


def series_stats(rows):
    if not rows:
        return {"count": 0}
    ts = [float(r["timestamp"]) for r in rows if r.get("timestamp") is not None]
    vals = [r.get("value") for r in rows]
    gaps = [b - a for a, b in zip(ts, ts[1:])]
    changes = 0
    for a, b in zip(vals, vals[1:]):
        if a != b:
            changes += 1
    return {
        "count": len(rows),
        "first_ts": min(ts) if ts else None,
        "last_ts": max(ts) if ts else None,
        "max_gap_s": max(gaps) if gaps else None,
        "median_gap_s": statistics.median(gaps) if gaps else None,
        "changes": changes,
    }


def recent_history(role, hours=24):
    now = time.time(); start = now - hours * 3600
    result = {"available": False, "hours": hours, "channels": {}, "ok_zero_events": [], "notes": []}
    try:
        catalog = history_channels()
    except Exception as exc:
        result["error"] = str(exc)
        return result
    result["available"] = True
    pairs = ROLE_PAIRS[role]
    expected = [p for pair in pairs for p in pair]
    if role == "gazebo":
        expected += [GAZEBO_AIR, "NL_combo_thermostat_504/floor_valid", "NL_combo_thermostat_504/demand_valid"]
    for p in expected:
        meta = catalog.get(p)
        result["channels"][p] = meta or {"missing": True}
    # One compact query for all OK channels and representative temperature channels.
    ok_paths = [ok for _, ok in pairs if ok in catalog]
    if role == "boiler":
        reps = ["wb-m1w2_170/External Sensor 1", "902.11_M1W2_TEMP_NONE/External Sensor 1",
                "903.09_TEMP_NONE/External Sensor 1"]
    else:
        reps = [pairs[0][0], "NL_combo_thermostat_504/floor_valid"]
    query = ok_paths + [p for p in reps if p in catalog and p not in ok_paths]
    try:
        rows = by_path(history_values(query, start, now, max_records=5000)) if query else {}
    except Exception as exc:
        result["notes"].append("get_values failed: %s" % exc)
        rows = {}
    result["stats"] = {p: series_stats(rows.get(p, [])) for p in query}
    for p in ok_paths:
        for row in rows.get(p, []):
            v = numeric(row.get("min"))
            if v is None:
                v = numeric(row.get("value"))
            if v is not None and v < 0.5:
                result["ok_zero_events"].append({"path": p, "timestamp": row.get("timestamp"), "value": row.get("value")})
    # Coverage is metadata-based: useful even when value query is sparse.
    covered = sum(1 for p in expected if p in catalog)
    result["coverage"] = {"expected": len(expected), "covered": covered, "ratio": covered / float(len(expected) or 1)}
    return result


def incident_history_gazebo():
    # Whole local calendar day intentionally covers the known historical clock issue.
    local = dt.datetime.now().astimezone().tzinfo
    start_dt = dt.datetime(2026, 9, 25, 0, 0, tzinfo=local)
    end_dt = dt.datetime(2026, 9, 26, 0, 0, tzinfo=local)
    result = {"window": [start_dt.isoformat(), end_dt.isoformat()], "available": False, "candidates": []}
    try:
        catalog = history_channels()
    except Exception as exc:
        result["error"] = str(exc); return result
    temp = GAZEBO_M1W2[0][0]; ok = GAZEBO_M1W2[0][1]; valid = "NL_combo_thermostat_504/floor_valid"
    paths = [p for p in (temp, ok, valid) if p in catalog]
    result["available"] = bool(paths)
    result["present"] = paths
    if not paths:
        return result
    try:
        rows = by_path(history_values_paged(paths, start_dt.timestamp(), end_dt.timestamp()))
    except Exception as exc:
        result["error"] = str(exc); return result
    result["stats"] = {p: series_stats(rows.get(p, [])) for p in paths}
    # Detect 1->0 floor_valid transitions; classify only when latest temp is in-range and latest OK=1.
    if valid not in rows:
        return result
    temp_rows = rows.get(temp, []); ok_rows = rows.get(ok, [])
    def latest_before(series, stamp):
        candidate = None
        for row in series:
            if float(row.get("timestamp", 0)) <= stamp:
                candidate = row
            else:
                break
        return candidate
    prev = None
    for row in rows[valid]:
        v = numeric(row.get("value")); stamp = float(row.get("timestamp", 0))
        if prev is not None and prev >= 0.5 and v is not None and v < 0.5:
            tr = latest_before(temp_rows, stamp); hr = latest_before(ok_rows, stamp)
            tv = numeric(tr.get("value")) if tr else None
            hv = numeric(hr.get("value")) if hr else None
            healthy = tv is not None and -20 <= tv <= 70 and hv is not None and hv >= 0.5
            result["candidates"].append({"timestamp": stamp, "temperature": tv, "ok": hv, "healthy_cache": healthy})
        if v is not None:
            prev = v
    stamps = [c["timestamp"] for c in result["candidates"] if c["healthy_cache"]]
    result["candidate_intervals_s"] = [b-a for a,b in zip(stamps, stamps[1:])]
    return result


def db_config_summary():
    path = Path("/etc/wb-mqtt-db.conf")
    result = {"path": str(path), "present": path.exists()}
    if not path.exists():
        return result
    try:
        raw = path.read_bytes()
        result["sha256"] = sha256(raw)
        cfg = json.loads(raw.decode("utf-8"))
        result["database"] = cfg.get("database")
        result["groups"] = [{k: g.get(k) for k in ("name", "channels", "values", "values_total", "min_interval", "min_unchanged_interval", "max_burst")}
                            for g in cfg.get("groups", []) if isinstance(g, dict)]
    except Exception as exc:
        result["error"] = str(exc)
    return result


def gazebo_journal_history():
    """Best-effort local journal evidence for the historical #75 day; absence is not a failure."""
    cmd = ["journalctl", "-u", "wb-rules", "-u", "wb-mqtt-serial",
           "--since", "2026-09-25 00:00:00", "--until", "2026-09-26 00:00:00",
           "--no-pager", "-o", "short-unix"]
    p = run(cmd, timeout=30)
    result = {"rc": p.returncode, "available": p.returncode == 0 and bool(p.stdout.strip()),
              "floor_invalid": [], "serial_restart_lines": []}
    if p.returncode != 0:
        result["error"] = p.stderr.strip()
        return result
    stamps = []
    for line in p.stdout.splitlines():
        if "FLOOR_SENSOR_INVALID" in line and ("624_combo_besedka" in line or "[504" in line or "504 " in line):
            result["floor_invalid"].append(line)
            try: stamps.append(float(line.split(None, 1)[0]))
            except Exception: pass
        if "wb-mqtt-serial" in line and re.search(r"Started|Stopped|SIGTERM|Starting", line, re.I):
            result["serial_restart_lines"].append(line)
    result["floor_invalid_intervals_s"] = [b-a for a,b in zip(stamps, stamps[1:])]
    return result


def history_bundle(role, hours=24):
    result = {"role": role, "time": dt.datetime.now().astimezone().isoformat(),
              "db_config": db_config_summary(), "recent": recent_history(role, hours)}
    if role == "gazebo":
        result["issue75_db"] = incident_history_gazebo()
        result["issue75_journal"] = gazebo_journal_history()
    return result


def package_version(name):
    p = run(["dpkg-query", "-W", "-f=${Version}", name], timeout=10)
    return p.stdout.strip() if p.returncode == 0 else None


def service_state(name):
    p = run(["systemctl", "is-active", name], timeout=10)
    return p.stdout.strip() if p.stdout.strip() else "unknown"


def nli_cmd(args, timeout=120):
    return run(["nli"] + args, timeout=timeout)


def config_role():
    try:
        data = json.loads(CONFIG.read_text())
        return data.get("role"), data
    except Exception:
        return None, None


def current_snapshot(role):
    paths = [p for pair in ROLE_PAIRS[role] for p in pair]
    if role == "gazebo":
        paths.append(GAZEBO_AIR)
    snap, err = mqtt_multi_snapshot(paths, timeout=3)
    bad = []
    for value_path, ok_path in ROLE_PAIRS[role]:
        v = numeric((snap.get(value_path) or {}).get("value"))
        ok = str((snap.get(ok_path) or {}).get("value", "")).lower()
        ve = (snap.get(value_path) or {}).get("error")
        he = (snap.get(ok_path) or {}).get("error")
        if v is None or v < -40 or v > 120 or ok not in ("1", "true") or ve not in (None, "") or he not in (None, ""):
            bad.append({"value": value_path, "temperature": v, "ok": ok, "value_error": ve, "ok_error": he})
    if role == "gazebo" and numeric((snap.get(GAZEBO_AIR) or {}).get("value")) is None:
        bad.append({"value": GAZEBO_AIR, "error": "air sensor unavailable"})
    return {"snapshot": snap, "bad": bad, "error": err}


def preflight(role, history_hours=24, verbose=True):
    report = {"role": role, "time": dt.datetime.now().astimezone().isoformat(), "pass": True, "checks": {}}
    actual_role, cfg = config_role()
    report["checks"]["nli_config_role"] = {"expected": role, "actual": actual_role, "pass": actual_role == role}
    if actual_role != role:
        report["pass"] = False
    versions = {name: package_version(name) for name in ("neiro-nli", "wb-rules", "wb-mqtt-serial", "wb-mqtt-db")}
    report["checks"]["versions"] = versions
    if versions.get("neiro-nli") != NLI_VERSION:
        report["pass"] = False
    services = {name: service_state(name) for name in ("wb-rules", "wb-mqtt-serial", "wb-mqtt-db")}
    report["checks"]["services"] = services
    if services["wb-rules"] != "active" or services["wb-mqtt-serial"] != "active":
        report["pass"] = False
    status = nli_cmd(["--json", "status"], timeout=30)
    check = nli_cmd(["--json", "check", "hhm"], timeout=90)
    report["checks"]["nli_status"] = {"rc": status.returncode, "stdout": status.stdout.strip(), "stderr": status.stderr.strip()}
    report["checks"]["nli_check_before_stage"] = {"rc": check.returncode, "stdout": check.stdout.strip(), "stderr": check.stderr.strip()}
    if status.returncode != 0:
        report["pass"] = False
    snap = current_snapshot(role)
    report["checks"]["current_m1w2"] = snap
    if snap["bad"]:
        report["pass"] = False
    probe = probe_port_load(role)
    report["checks"]["port_load_probe"] = probe
    if not probe.get("pass"):
        report["pass"] = False
    history_pack = history_bundle(role, history_hours)
    history = history_pack["recent"]
    report["checks"]["history"] = history_pack
    if role == "gazebo":
        incident = history_pack.get("issue75_db") or {}
        journal_hist = history_pack.get("issue75_journal") or {}
        intervals = [x for x in (incident.get("candidate_intervals_s") or []) if x > 0]
        intervals += [x for x in (journal_hist.get("floor_invalid_intervals_s") or []) if x > 0]
        if intervals:
            evidence_max = max(intervals)
            report["recommended_soak_s"] = max(600, min(900, int(math.ceil(evidence_max * 1.5 / 30.0) * 30)))
        else:
            # Existing #75 live evidence already has max recurrence interval 395 s.
            report["recommended_soak_s"] = max(600, int(math.ceil(KNOWN_75_MAX_INTERVAL_S * 1.5 / 30.0) * 30))
    else:
        cov = (history.get("coverage") or {}).get("ratio", 0)
        report["recommended_stability_s"] = 120 if cov >= 0.8 and not history.get("ok_zero_events") else 180
    if verbose:
        print("=== HHM 3.1 PRE-FLIGHT: %s ===" % role)
        print("NLI=%s wb-rules=%s wb-mqtt-serial=%s" % (versions.get("neiro-nli"), versions.get("wb-rules"), versions.get("wb-mqtt-serial")))
        print("services: %s" % services)
        print("current M1W2: %s" % ("PASS" if not snap["bad"] else "FAIL (%d bad)" % len(snap["bad"])))
        print("port/Load: %s%s" % ("PASS" if probe.get("pass") else "FAIL", "" if probe.get("pass") else " · " + str(probe.get("error"))))
        hcov = (history.get("coverage") or {})
        print("history: %s/%s expected channels; OK=0 events=%d" % (hcov.get("covered", 0), hcov.get("expected", 0), len(history.get("ok_zero_events") or [])))
        if role == "gazebo":
            print("gazebo soak recommendation: %ss" % report["recommended_soak_s"])
        else:
            print("boiler stability recommendation after qualification: %ss" % report["recommended_stability_s"])
        print("RESULT: %s" % ("READY_FOR_STAGING" if report["pass"] else "STOP"))
    return report


def manifest_bytes(role):
    meta = MANIFEST[role]
    url = "https://raw.githubusercontent.com/%s/%s/%s" % (REPO, PR_HEAD, meta["path"])
    with urllib.request.urlopen(url, timeout=30) as response:
        data = response.read(2 * 1024 * 1024)
    actual = sha256(data)
    if actual != meta["sha256"]:
        raise RuntimeError("manifest SHA mismatch: expected %s got %s" % (meta["sha256"], actual))
    obj = json.loads(data.decode("utf-8"))
    if obj.get("version") != "3.1" or (obj.get("release") or {}).get("commit") != RUNTIME_COMMIT or obj.get("role") != role:
        raise RuntimeError("manifest identity mismatch")
    return data


def atomic_write_json(path, obj, mode=0o600):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2, sort_keys=False)
            f.write("\n"); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
        dfd = os.open(str(path.parent), os.O_DIRECTORY)
        try: os.fsync(dfd)
        finally: os.close(dfd)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass


def stage_target(role, apply=False):
    if os.geteuid() != 0:
        raise RuntimeError("stage requires root")
    actual_role, cfg = config_role()
    if actual_role != role or not cfg:
        raise RuntimeError("NLI config role mismatch")
    data = manifest_bytes(role)
    target_name = "hhm-%s-3.1-retry-%s.json" % (role, RUNTIME_COMMIT[:8])
    target = RELEASE_DIR / target_name
    result = {"role": role, "target": str(target), "sha256": MANIFEST[role]["sha256"], "apply": apply}
    if not apply:
        return result
    if STAGE_BACKUP.exists():
        raise RuntimeError("staging backup already exists: %s; restore/inspect first" % STAGE_BACKUP)
    RELEASE_DIR.mkdir(parents=True, exist_ok=True)
    STAGE_BACKUP.write_bytes(CONFIG.read_bytes())
    os.chmod(STAGE_BACKUP, 0o600)
    target.write_bytes(data); os.chmod(target, 0o644)
    staged = json.loads(CONFIG.read_text())
    staged["release_source"] = "pinned"
    component = staged.setdefault("components", {}).setdefault("hhm", {})
    if "baseline" not in component:
        raise RuntimeError("HHM baseline missing from NLI config")
    component["target"] = {"path": str(target), "sha256": MANIFEST[role]["sha256"]}
    atomic_write_json(CONFIG, staged, 0o600)
    result["backup"] = str(STAGE_BACKUP)
    return result


def unstage():
    if os.geteuid() != 0:
        raise RuntimeError("unstage requires root")
    if not STAGE_BACKUP.exists():
        raise RuntimeError("no staging backup found")
    old = STAGE_BACKUP.read_bytes()
    fd, tmp = tempfile.mkstemp(prefix="config.restore.", dir=str(CONFIG.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(old); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp, 0o600); os.replace(tmp, CONFIG)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass
    for role in ("boiler", "gazebo"):
        p = RELEASE_DIR / ("hhm-%s-3.1-retry-%s.json" % (role, RUNTIME_COMMIT[:8]))
        if p.exists() and sha256(p.read_bytes()) == MANIFEST[role]["sha256"]:
            p.unlink()
    STAGE_BACKUP.unlink()


def journal_since(epoch):
    p = run(["journalctl", "-u", "wb-rules", "--since", "@%d" % int(epoch), "--no-pager", "-o", "short-unix"], timeout=30)
    return p.stdout


def parse_valid_paths(journal, expected):
    valid = set(); proof_errors = []; floor_invalid_after_valid = 0; gazebo_valid_seen = False
    for line in journal.splitlines():
        for path in expected:
            if ("[M1W2 %s]" % path) in line and '"phase":"RUNTIME"' in line and '"reason":"VALID"' in line:
                valid.add(path)
                if path == GAZEBO_M1W2[0][0]: gazebo_valid_seen = True
        if "POST_START_PROOF=" in line:
            proof_errors.append(line)
        if gazebo_valid_seen and "FLOOR_SENSOR_INVALID" in line:
            floor_invalid_after_valid += 1
    return valid, proof_errors, floor_invalid_after_valid


def capture_live(role, duration_s, output):
    topics = []
    if role == "gazebo":
        topics = [
            mqtt_topic(GAZEBO_M1W2[0][0]), mqtt_topic(GAZEBO_M1W2[0][1]),
            mqtt_topic("NL_combo_thermostat_504/floor_valid"), mqtt_topic("NL_combo_thermostat_504/reason"),
            mqtt_topic("NL_combo_thermostat_504/sensor_health_contract"),
            "/neiro/ivolga/504/v2/frame",
        ]
    else:
        topics = [mqtt_topic("HHM3_FSE/runtime_status"), mqtt_topic("HHM3_FSE/operational_status"),
                  mqtt_topic("HHM3_FSE/sensor_health_contract")]
    cmd = ["mosquitto_sub", "-h", "127.0.0.1", "-W", str(duration_s), "-F", "%U\t%r\t%t\t%p"]
    for t in topics: cmd += ["-t", t]
    with open(output, "w", encoding="utf-8") as f:
        p = subprocess.run(cmd, stdout=f, stderr=subprocess.PIPE, text=True, timeout=duration_s + 10)
    return p.returncode in (0, 27), p.stderr.strip()


def final_virtual_snapshot(role):
    paths = ["NL_combo_thermostat_504/floor_valid", "NL_combo_thermostat_504/reason",
             "NL_combo_thermostat_504/sensor_health_contract"] if role == "gazebo" else [
             "HHM3_FSE/runtime_status", "HHM3_FSE/operational_status", "HHM3_FSE/sensor_health_contract"]
    snap, err = mqtt_multi_snapshot(paths, timeout=2)
    return {"snapshot": snap, "error": err}


def postinstall_smoke(role, since_epoch, duration_s=None):
    expected = [p for p, _ in ROLE_PAIRS[role]]
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    live_file = REPORT_DIR / ("live-%s-%s.tsv" % (role, stamp))
    if role == "gazebo":
        duration_s = duration_s or 600
    else:
        duration_s = duration_s or 120
    print("=== POST-INSTALL SMOKE: %s ===" % role)
    print("passive live capture: %ss" % duration_s)
    ok, capture_err = capture_live(role, duration_s, live_file)
    journal = journal_since(since_epoch)
    valid, proof_errors, floor_invalid_after_valid = parse_valid_paths(journal, expected)
    final = final_virtual_snapshot(role)
    verify = nli_cmd(["--json", "verify", "hhm"], timeout=60)
    report = {
        "role": role, "since_epoch": since_epoch, "duration_s": duration_s,
        "live_capture": str(live_file), "capture_ok": ok, "capture_error": capture_err,
        "qualified": sorted(valid), "missing_qualification": sorted(set(expected) - valid),
        "proof_errors": proof_errors, "floor_invalid_after_valid": floor_invalid_after_valid,
        "final": final, "nli_verify_rc": verify.returncode, "nli_verify": verify.stdout.strip(),
        "pass": True,
    }
    if not ok or verify.returncode != 0 or report["missing_qualification"]:
        report["pass"] = False
    snap = final["snapshot"]
    if role == "gazebo":
        floor_valid = str((snap.get("NL_combo_thermostat_504/floor_valid") or {}).get("value", "")).lower()
        reason = str((snap.get("NL_combo_thermostat_504/reason") or {}).get("value", ""))
        contract = str((snap.get("NL_combo_thermostat_504/sensor_health_contract") or {}).get("value", ""))
        if floor_valid not in ("1", "true") or reason == "FLOOR_SENSOR_INVALID" or contract != HEALTH_CONTRACT or floor_invalid_after_valid:
            report["pass"] = False
        # Count fresh numeric publications during the soak. Zero is stronger #75 evidence, not a hard requirement.
        fresh_numeric = 0
        raw_topic = mqtt_topic(GAZEBO_M1W2[0][0])
        try:
            for line in live_file.read_text().splitlines():
                parts = line.split("\t", 3)
                if len(parts) == 4 and parts[1] == "0" and parts[2] == raw_topic:
                    fresh_numeric += 1
        except Exception:
            pass
        report["fresh_numeric_publications"] = fresh_numeric
    else:
        contract = str((snap.get("HHM3_FSE/sensor_health_contract") or {}).get("value", ""))
        runtime_status = str((snap.get("HHM3_FSE/runtime_status") or {}).get("value", ""))
        if contract != HEALTH_CONTRACT or "RUNTIME_UNSUPPORTED" in runtime_status:
            report["pass"] = False
    report_file = REPORT_DIR / ("smoke-%s-%s.json" % (role, stamp))
    report_file.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print("qualified M1W2: %d/%d" % (len(valid), len(expected)))
    print("proof warnings: %d" % len(proof_errors))
    if role == "gazebo":
        print("false FLOOR_SENSOR_INVALID after first VALID: %d" % floor_invalid_after_valid)
        print("fresh numeric publications during soak: %d" % report.get("fresh_numeric_publications", 0))
    print("NLI verify: %s" % ("PASS" if verify.returncode == 0 else "FAIL"))
    print("REPORT: %s" % report_file)
    print("RESULT: %s" % ("PASS" if report["pass"] else "FAIL"))
    return report


def controlled_retry(role, history_hours=24, execute=False):
    gate = preflight(role, history_hours, verbose=True)
    if not gate["pass"]:
        print("STOP: pre-flight failed")
        return 2
    if not execute:
        print("DRY RUN ONLY: add --execute-update to permit staging + NLI update")
        return 0
    staged = stage_target(role, apply=True)
    print("staged target: %s" % staged["target"])
    check = nli_cmd(["--json", "check", "hhm"], timeout=120)
    print(check.stdout.strip())
    if check.returncode != 0:
        eprint(check.stderr.strip()); print("STOP: NLI check failed; staging left in place for inspection")
        return 3
    token = "UPDATE %s" % role.upper()
    answer = input("Type '%s' to run nli update hhm: " % token)
    if answer.strip() != token:
        print("Cancelled; staging left in place. Use 'unstage' to restore config.")
        return 0
    since = time.time() - 1
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    update_file = REPORT_DIR / ("update-%s-%s.json" % (role, dt.datetime.now().strftime("%Y%m%d-%H%M%S")))
    update = nli_cmd(["--json", "update", "hhm"], timeout=300)
    update_file.write_text(update.stdout + ("\nSTDERR:\n" + update.stderr if update.stderr else ""))
    print(update.stdout.strip())
    if update.returncode != 0:
        print("STOP: NLI update failed. See %s" % update_file)
        return 4
    duration = gate.get("recommended_soak_s") if role == "gazebo" else gate.get("recommended_stability_s")
    smoke = postinstall_smoke(role, since, duration_s=duration)
    if not smoke["pass"]:
        print("FUNCTIONAL SMOKE FAILED. No automatic rollback was executed.")
        print("Recommended next action after review: nli --json rollback hhm")
        return 5
    print("CONTROLLED RETRY PASSED for %s" % role)
    print("Keep staging until both controllers are accepted or an approved HHM release is published.")
    return 0


def selftest():
    sample = """1.0 host wb-rules: [отопление][624_combo_besedka][M1W2 921.10_TEMP_NONE/External Sensor 1]; {\"phase\":\"RUNTIME\",\"reason\":\"VALID\",\"cause\":\"POLL_QUALIFIED\"}
2.0 host wb-rules: [отопление][624_combo_besedka][504]; FLOOR_SENSOR_INVALID
"""
    valid, proof, false_after = parse_valid_paths(sample, [GAZEBO_M1W2[0][0]])
    assert GAZEBO_M1W2[0][0] in valid
    assert false_after == 1
    assert not proof
    assert series_stats([])["count"] == 0
    stats = series_stats([{ "timestamp": 1, "value": 1 }, { "timestamp": 6, "value": 1 }, { "timestamp": 10, "value": 2 }])
    assert stats["max_gap_s"] == 5
    assert stats["changes"] == 1
    print("SELFTEST: PASS · tool %s" % TOOL_VERSION)
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("selftest")
    a = sub.add_parser("history"); a.add_argument("--role", choices=("gazebo","boiler"), required=True); a.add_argument("--hours", type=int, default=24); a.add_argument("--json-out")
    a = sub.add_parser("preflight"); a.add_argument("--role", choices=("gazebo","boiler"), required=True); a.add_argument("--history-hours", type=int, default=24); a.add_argument("--json-out")
    a = sub.add_parser("probe"); a.add_argument("--role", choices=("gazebo","boiler"), required=True)
    a = sub.add_parser("stage"); a.add_argument("--role", choices=("gazebo","boiler"), required=True); a.add_argument("--apply", action="store_true")
    sub.add_parser("unstage")
    a = sub.add_parser("smoke"); a.add_argument("--role", choices=("gazebo","boiler"), required=True); a.add_argument("--since-epoch", type=float, required=True); a.add_argument("--duration", type=int)
    a = sub.add_parser("retry"); a.add_argument("--role", choices=("gazebo","boiler"), required=True); a.add_argument("--history-hours", type=int, default=24); a.add_argument("--execute-update", action="store_true")
    args = p.parse_args(argv)
    try:
        if args.cmd == "selftest":
            return selftest()
        if args.cmd == "history":
            r = history_bundle(args.role, args.hours)
            out = json.dumps(r, indent=2, ensure_ascii=False) + "\n"
            print(out, end="")
            if args.json_out: Path(args.json_out).write_text(out)
            return 0
        if args.cmd == "preflight":
            r = preflight(args.role, args.history_hours, verbose=True)
            if args.json_out: Path(args.json_out).write_text(json.dumps(r, indent=2, ensure_ascii=False) + "\n")
            return 0 if r["pass"] else 2
        if args.cmd == "probe":
            r = probe_port_load(args.role); print(json.dumps(r, indent=2, ensure_ascii=False)); return 0 if r.get("pass") else 2
        if args.cmd == "stage":
            print(json.dumps(stage_target(args.role, apply=args.apply), indent=2)); return 0
        if args.cmd == "unstage":
            unstage(); print("staging restored and temporary retry manifest removed"); return 0
        if args.cmd == "smoke":
            r = postinstall_smoke(args.role, args.since_epoch, args.duration); return 0 if r["pass"] else 5
        if args.cmd == "retry":
            return controlled_retry(args.role, args.history_hours, execute=args.execute_update)
    except KeyboardInterrupt:
        eprint("Interrupted. No automatic rollback/unstage was performed."); return 130
    except Exception as exc:
        eprint("ERROR:", exc); return 1


if __name__ == "__main__":
    raise SystemExit(main())
